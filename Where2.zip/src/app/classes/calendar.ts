import {Event} from './event';
export class Calendar {
    eventList: Event[];
    constructor() {
    }
}
