import { Calendar } from './calendar';

describe('calendar', () => {
  it('should create an instance', () => {
    expect(new Calendar()).toBeTruthy();
  });
});
