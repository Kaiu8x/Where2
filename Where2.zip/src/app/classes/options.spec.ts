import { Options } from './options';

describe('Options', () => {
  it('should create an instance', () => {
    expect(new Options()).toBeTruthy();
  });
});
