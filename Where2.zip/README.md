# Si no jala checar el branch functioning.

# Where2

Team members:
- Kai Kawasaki Ueda A01336424
- Sergio Ugalde Marcano A01336435
- Santiago Gutiérrez Bárcenas A01652520

## Internacionalización
Se utilizó con botones en el top nav bar y solo para cambiar el texto del bottom nav bar dado que el texto que se encuentra es por el momento dummy y son cosas que se jalaran de la base.

## Investigación
Se utilizó la animación en las cartas que se muestran en home usando un fade in effect cambiando la opacidad de los componentes. \n Se utilizaron las gráficas en home jalando la info de un dummy por el momento pero esta gráfica menciona la actividad del usuario por semana.

## Router
Se incorporó Router el cual se puede navegar usando el nav bar de abajo, se utilizó la convención para ver los eventos de mandar el event id en la url para ver ese event detail.

## Angular-in-memory-web-api
Se utiliza en la parte de event details para jalar la información. Se extenderá a los otros componentes.

## Correciones

Se incorpora las estadísticas y un hitorial de los evenots en My Events. Al igual que se incorporan las sugerencias dichas como la descripción y información de cada evento en las cartas.
